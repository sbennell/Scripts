# Readme files for CIS Level 1 Configurations

- [Baseline Security Configurations](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%201/Settings%20Catalog/Baseline%20Security%20Configurations)
- [Disable AirDrop and Handoff](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%201/Settings%20Catalog/Disable%20AirDrop%20and%20Handoff)
- [Disable Guest Accounts](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%201/Settings%20Catalog/Disable%20Guest%20Accounts)
- [Disable Internet Sharing Modification](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%201/Settings%20Catalog/Disable%20Internet%20Sharing%20Modification)
- [Disable Wake for Network](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%201/Settings%20Catalog/Disable%20Wake%20for%20Network)
- [Filevault](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%201/Settings%20Catalog/Filevault)
- [Gatekeeper](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%201/Settings%20Catalog/Gatekeeper)
- [Password Management](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%201/Settings%20Catalog/Password%20Management)
- [Privacy Restrictions](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%201/Settings%20Catalog/Privacy%20Restrictions)
- [Screensaver password](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%201/Settings%20Catalog/Screensaver%20password)
- [Software update](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%201/Settings%20Catalog/Software%20update)
- [TimeServer](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%201/Settings%20Catalog/TimeServer)