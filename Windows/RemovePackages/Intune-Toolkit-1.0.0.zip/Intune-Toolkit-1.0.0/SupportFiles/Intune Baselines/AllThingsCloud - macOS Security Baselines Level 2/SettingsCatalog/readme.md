# Readme files for CIS Level 2 Configurations

- [CIS Level 2 Baseline configuration](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%202/Settings%20Catalog/CIS%20Level%202%20Baseline%20configuration)
- [Disable Content Cashing](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%202/Settings%20Catalog/Disable%20Content%20Cashing)
- [Disable Siri Completely](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%202/Settings%20Catalog/Disable%20Siri%20Completely)
- [Disable iCloud Documents and Desktop Sync](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%202/Settings%20Catalog/Disable%20iCloud%20Documents%20and%20Desktop%20Sync)
- [Notifications and Focus Settings](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%202/Settings%20Catalog/Notifications%20and%20Focus%20Settings)
- [Power Settings](https://github.com/oktay-sari/Intune-Goodies/tree/main/macOS/macOS%20Security%20Baselines/Level%202/Settings%20Catalog/Power%20Settings)